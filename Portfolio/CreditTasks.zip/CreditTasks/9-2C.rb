# Recursive Factorial

# Complete the following
def factorial(n)
  if (n <= 0) 
    output = "Incorrect argument - need a single argument with a value of 0 or more.\n"
    return output
  elsif (n == 1) 
    return 1
  else
    return n*factorial(n-1)
  end
end

def main
  puts factorial(ARGV[0].to_i)
end

main
