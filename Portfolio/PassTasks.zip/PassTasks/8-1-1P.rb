
# put the genre names array here:
module Genre
  POP, CLASSIC, JAZZ, ROCK = *1..4
end

$genre_names = ['Null', 'Pop', 'Classic', 'Jazz', 'Rock']

def main()
  i = 1
  while i < $genre_names.length do
    puts i.to_s + " " + $genre_names[i].to_s
    i += 1
  end
end

main()
