name = input("Enter your name: ")
print("Hello, "+name+"!")
age = input("Enter your age: ")
print("You are "+age+" years old")
