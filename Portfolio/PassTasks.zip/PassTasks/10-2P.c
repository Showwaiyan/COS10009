#include <stdio.h>

void print_message(char *message)
{
    printf("%s", message);
}

int main()
{
  print_message("Hello World!\n");
  return 0;
}
