def main()
    puts "Hello World"
end

main()
