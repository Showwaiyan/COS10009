require "./input_functions"
# put your code below
class Track
	attr_accessor :name, :location
	def initialize(name, location)
		@name = name
		@locatoin = location
	end
end

def read_track()
	read_name = read_string("Enter track name:")
	read_location = read_string("Enter track location:")

	track = Track.new(read_name, read_location)
	return track
end

def print_track(track)
	puts "Track name: "+track.name.to_s
	puts "Track location: "+track.location.to_s
end

def main()
	track = read_track()
	print_track(track)
end

# leave this line
main() if __FILE__ == $0
